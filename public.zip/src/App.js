import React from 'react'
import { Wrapper } from './Components/Wrapper'
import "./Style/Style.css"
import "./Media/Media.css"
export function App() {
  return (
    <div>
      <Wrapper/>
    </div>
  )
}

