import React from 'react'

// Imgs
import cube1 from "../../../../Imgs/Home/Header/cubic1.png"
import cube2 from "../../../../Imgs/Home/Header/cubic2.png"
import cube3 from "../../../../Imgs/Home/Header/cubic3.png"
import img1 from "../../../../Imgs/Home/Header/hmImg1.png"
import img2 from "../../../../Imgs/Home/Header/hmImg2.png"
import img3 from "../../../../Imgs/Home/Header/hmImg3.png"
import { useNavigate } from 'react-router-dom'

export function Header() {
    let portal = useNavigate()
  return (
    <div className='homeHeader'>
        <div className="hmHrLeft">
            <div className="hmLeftText1">
                <p>BEST SELLER</p>
                <h1>BEST DISPENSARY TO BUY WEED ONLINE </h1>
                <span>Vitamins & Supplements</span>
            </div>
            <div className="hmLeftText2">
                <p>Get 25% off</p>
                <hr />
                <p>Free Shipping</p>
            </div>
            <button className='hmLeftBtn' onClick={()=> portal("/categorypage")}>Shop All</button>
        </div>
        <div className="hmHrRight">
            <img src={cube1} alt="img" />
            <img src={img1} alt="img" />
            <img src={cube2} alt="img" />
            <img src={img2} alt="img" />
            <img src={cube3} alt="img" />
            <img src={img3} alt="img" />
        </div>
    </div>
  )
}
