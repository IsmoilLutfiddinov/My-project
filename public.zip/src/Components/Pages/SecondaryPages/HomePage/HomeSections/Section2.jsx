import React, { useState } from "react";
// Imgs
import img1 from "../../../../Imgs/Home/Section2/img1.png";
import img2 from "../../../../Imgs/Home/Section2/img2.png";
import img3 from "../../../../Imgs/Home/Section2/img3.png";
import img4 from "../../../../Imgs/Home/Section2/img4.png";

export function Section2() {
  const [card, setCard] = useState([
    {
      id: 1,
      name: "REGISTER",
      img: img1,
      content:
        "Sign up for an account with us. This is quick and simple. We don’t require any more details from you than the bare minimum needed for you to place an order and get your product delivered.",
    },
    {
      id: 2,
      name: "SHOP",
      img: img2,
      content:
        "Decide on what you want to purchase. We stock a wide range of edibles,flowers , concentrates and mushrooms there is bound to be something for everyone.",
    },
    {
      id: 3,
      name: "MAKE PAYMENT",
      img: img3,
      content:
        "Pay securely. Our site boasts sturdy protection certificates to keep your card details and related data safe.",
    },
    {
      id: 4,
      name: "RELAX",
      img: img4,
      content:
        "Your product will be packaged discretely and shipped by Canada Post Xpresspost. We will provide you with a tracking number so then you can follow your mail order marijuana every step of the way.",
    },
  ]);

  return (
    <div className="Section2">
      <div className="sec2Top">
        <h1>
          HOW TO ORDER WEED ONLINE FROM TOP SHELF BC - MAIL ORDER MARIJUANA
        </h1>
        <p>
          Ordering weed online from Top Shelf BC is easy. We are proud to have
          made the process accessible across multiple platforms and simple to
          understand, meaning that more people can come to us to buy their
          cannabis products online.
        </p>
      </div>
      <div className="sec2Btm">
        <div className="sec2Cards">
          {card.map((val, i) => (
            <div key={i} className="sec2Card">
              <div className="sec2CardImgBox">
                <p>{val.id}</p>
                <img src={val.img} alt="img" />
              </div>
              <div className="sec2CardContent">
                <h1>{val.name}</h1>
                <p>{val.content}</p>
              </div>
            </div>
          ))}
        </div>
        <button className="sec2Btm">Choose your Weed</button>
      </div>
    </div>
  );
}
